// public/main.js
const $ = (s) => document.querySelector(s);
const api = (path, opts={}) => fetch(path, opts).then(r => r.json());

let socket = null;
let currentRoom = null;
let syncing = false;

function setHidden(el, hidden) { hidden ? el.classList.add('hidden') : el.classList.remove('hidden'); }

function formatExpiry(ts) {
  const d = new Date(ts);
  return `Expires at ${d.toLocaleTimeString()} (${Math.round((ts - Date.now())/60000)} min left)`;
}

async function createRoom() {
  const res = await api('/api/room', { method: 'POST' });
  joinRoom(res.roomId, res.expiresAt);
}

function cleanRoomId(raw) {
  return (raw || '').trim().replace(/[^0-9a-zA-Z]/g, '');
}

async function joinRoom(roomId, expiresAt) {
  currentRoom = roomId;
  const url = new URL(window.location.href);
  url.searchParams.set('room', roomId);
  history.replaceState(null, '', url.toString());

  // Show UI
  $('#roomId').textContent = roomId;
  $('#expiry').textContent = expiresAt ? formatExpiry(expiresAt) : '';
  setHidden($('#room'), false);
  setHidden($('#setup'), true);

  // QR code
  const roomUrl = `${location.origin}?room=${encodeURIComponent(roomId)}`;
  QRCode.toCanvas($('#qrcanvas'), roomUrl, { width: 160 });

  // Socket
  socket = io();
  socket.on('connect', () => socket.emit('join', roomId));
  socket.on('room:joined', ({ text, expiresAt }) => {
    $('#textArea').value = text || '';
    $('#expiry').textContent = formatExpiry(expiresAt);
  });
  socket.on('room:error', (msg) => alert(msg));
  socket.on('text:sync', ({ text }) => {
    syncing = true;
    $('#textArea').value = text || '';
    setTimeout(()=> syncing=false, 50);
  });
  socket.on('file:available', (file) => addFile(file));

  // Load current state (in case socket connects late)
  try {
    const info = await api(`/api/room/${roomId}`);
    $('#textArea').value = info.text || '';
    $('#expiry').textContent = formatExpiry(info.expiresAt);
  } catch(e){ /* ignore */ }
}

function addFile(file) {
  const el = document.createElement('div');
  el.className = 'fileItem';
  const sizeKB = Math.ceil(file.size/1024);
  el.innerHTML = `<div><strong>${file.name}</strong><div class="muted">${sizeKB} KB</div></div>
                  <a href="${file.url}" download>Download</a>`;
  $('#files').prepend(el);
}

function setupHandlers() {
  $('#createRoomBtn').addEventListener('click', createRoom);
  $('#joinBtn').addEventListener('click', () => {
    const code = cleanRoomId($('#roomInput').value);
    if (code.length < 4) return alert('Enter a valid code');
    joinRoom(code);
  });
  $('#copyBtn').addEventListener('click', async () => {
    const link = `${location.origin}?room=${encodeURIComponent(currentRoom)}`;
    try {
      await navigator.clipboard.writeText(link);
      alert('Link copied!');
    } catch { prompt('Copy the link:', link); }
  });
  $('#uploadBtn').addEventListener('click', async () => {
    const f = $('#fileInput').files[0];
    if (!f) return alert('Choose a file first');
    const form = new FormData();
    form.append('file', f);
    const res = await fetch(`/api/upload/${currentRoom}`, { method: 'POST', body: form });
    if (!res.ok) {
      const err = await res.json().catch(()=>({error:'Upload failed'}));
      return alert(err.error || 'Upload failed');
    }
    const data = await res.json();
    addFile(data);
  });
  $('#textArea').addEventListener('input', (e) => {
    if (syncing) return;
    if (!socket || !currentRoom) return;
    socket.emit('text:update', { roomId: currentRoom, text: e.target.value });
  });

  // Auto-join if ?room= present
  const params = new URLSearchParams(location.search);
  const room = cleanRoomId(params.get('room'));
  if (room) joinRoom(room);
}

document.addEventListener('DOMContentLoaded', setupHandlers);
